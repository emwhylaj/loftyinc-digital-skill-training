
const accor = document.getElementsByClassName("accordion-item");


for (let i = 0; i < accor.length; i++){
    accor[i].addEventListener("click", function(){
        this.classList.toggle("active");
        let accordionPara = this.nextElementSibling;
        if (accordionPara.style.display === "block"){
            accordionPara.style.display = "none";
        }else{
            accordionPara.style.display = "block";
        }
    })
}