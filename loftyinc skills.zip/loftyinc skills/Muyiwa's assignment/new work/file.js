
for (let line = "#"; line.length < 8; line += "#"){
    console.log(line)
}

for (let m = 1; m <= 100; m++){
    let output = "";
    if (m % 3 == 0) output = "Fizz";
    if (m % 5 == 0) output = "Buzz";

    console.log(output || m)
}